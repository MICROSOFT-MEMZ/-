import tkinter as tk
import os
import tkinter.messagebox as mess
from tkinter import *
win=tk.Tk()
win.iconbitmap("ico.ico")
win.title("网易云音乐下载软件[仅供学习交流]")
win.resizable(0,0)
win.geometry("600x170")
win.config(background ="light green")
entry1 = tk.Entry(win,font=("微软雅黑",10),width=60)
entry1.place(x=28,y=75,anchor='w')
label1 = tk.Label(win, text="请在下方输入复制的链接[必须要完整]，然后点击确定",font=('微软雅黑',15, ''),fg="#00008B",bg="light green",width=45,height=1).place(x=-20,y=25,anchor='w')
def download():
    song = entry1.get()
    songid=song[30:-18]
    if entry1.get()=="":
        mess.showerror("错误","请先输入歌曲链接。")
    else:
        os.system("start http://music.163.com/song/media/outer/url?id="+songid+".mp3")
button = tk.Button(win, text="确定",font=('微软雅黑',15, ''), bg="#89CFF0",fg="red",width=8,command=download).place(x=450,y=130,anchor='w')
mess.showinfo("提示","该软件由MICROSOFT-MEMZ开发，请勿盗用")
win.mainloop()
